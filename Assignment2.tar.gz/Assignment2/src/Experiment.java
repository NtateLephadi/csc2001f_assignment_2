import java.util.Scanner;
import java.time.Duration;
import java.time.Instant;

public class Experiment
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		SearchAVL searchAVL = new SearchAVL();
		SearchIt searchIt = new SearchIt();
		PrintIt printIt = new PrintIt();
		Instant start, end;
		Duration deleteTime, insertTime, findTime;

		printIt.openPhoneDirectory();
		printIt.setNumber();
		printIt.writeToQueryList();

		System.out.println("Enter the number of tests you want to conduct: ");
		int numberOfTests = scanner.nextInt();

		String empty = scanner.nextLine();


		System.out.println("Are you testing an AVL or BST?\nEnter AVL or BST (upper case only): ");
		String typeOfTree = scanner.nextLine();

		switch(typeOfTree)
		{
			case "AVL":
				searchAVL.openPhoneDirectory();
				searchAVL.openQueryList();
				searchAVL.setNumber();

				start = Instant.now(); 
				for (int i = 0; i < numberOfTests; i++)
				{
					searchAVL.insert();
				}
				end = Instant.now();
				insertTime = Duration.between(start, end);

				start = Instant.now();
				for (int i = 0; i < numberOfTests; i++)
				{
					searchAVL.find();
				}
				end = Instant.now();
				findTime = Duration.between(start, end);

				start = Instant.now();
				for (int i = 0; i < numberOfTests; i++)
				{
					searchAVL.insert();
					searchAVL.delete();
				}
				end = Instant.now();
				deleteTime = Duration.between(start, end);

				System.out.println("Insertion time: " + insertTime.toMillis() + " milliseconds");
				System.out.println("Searching time: " + findTime.toMillis() + " milliseconds");
				System.out.println("Deletion time: " + deleteTime.toMillis() + " milliseconds");

				break;

			case "BST":
				searchIt.openPhoneDirectory();
				searchIt.openQueryList();
				searchIt.setNumber();

				start = Instant.now(); 
				for (int i = 0; i < numberOfTests; i++)
				{
					searchIt.insert();
				}
				end = Instant.now();
				insertTime = Duration.between(start, end);

				start = Instant.now();
				for (int i = 0; i < numberOfTests; i++)
				{
					searchIt.find();
				}
				end = Instant.now();
				findTime = Duration.between(start, end);

				start = Instant.now();
				for (int i = 0; i < numberOfTests; i++)
				{
					searchIt.insert();
					searchIt.delete();
				}
				end = Instant.now();
				deleteTime = Duration.between(start, end);

				System.out.println("Insertion time: " + insertTime.toMillis() + " milliseconds");
				System.out.println("Searching time: " + findTime.toMillis() + " milliseconds");
				System.out.println("Deletion time: " + deleteTime.toMillis() + " milliseconds");

				break;
			default:
				System.out.println("Tree not found");
				break;
		}
	}
}